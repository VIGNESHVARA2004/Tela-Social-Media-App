import React from 'react'
import Image from "../imgs/Logo.svg"
import Apple from "./download-on-the-app-store-apple-logo-svgrepo-com.svg";
import Google from "./Google_Play-Logo.wine.svg"
import './login.css'
export default function login() {
  return (
    <div className='main-box'>
        <div className='inner-box'>
            <div className='logo-box'><img alt ='logo' src={Image}/></div>
            <div className='login-box'>
              <div className='username-box'>
                <input type='text'></input>
                <label>Username</label>
              </div>
              <div className='password-box'>
                <input type='password'></input>
                <label>Password</label>
              </div>
              <div className='forgot-pass-box'>
                <p>Forgot Password?</p>
              </div>
            </div>
            <div className='register-link-box'>
              <p className='register-p'>Don't have an account? </p>
              <p className='Sign-up'>Sign up</p>
            </div>
            <div className='app-link-box'>
              <div className='app-text'><p>Get the app</p></div>
              <div className='logos'>
                <img alt='' src={Apple}/>
                <img alt='' src={Google}/>
              </div>
            </div>
        </div>
    </div>
  )
}
